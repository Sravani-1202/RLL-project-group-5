package com.foodbox.controllerTest;

import com.foodbox.controller.CustomerController;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import com.foodbox.controller.CustomerController;
import com.foodbox.model.Customer;
import com.foodbox.repository.CustomerRepository;
@ExtendWith(MockitoExtension.class)
public class CustomerControllerTests {
	@Mock
	private CustomerRepository customerRepository;
	@InjectMocks
	private CustomerController customerController;
	@Test
	public void testAddCustomer() {
	// Arrange
	Customer customerToAdd = new Customer("test@example.com",
	"password", "Test User", "1234567890", "Test Address");
	HttpSession session = mock(HttpSession.class);
	// Act
	Customer result = customerController.addCustomer(customerToAdd,
	session);
	// Assert
	/*assertThat(result).isNotNull();
	assertThat(result.getEmail()).isEqualTo(customerToAdd.getEmail());*/
	}
	@Test
	public void testVerifyLogin_Success() {
	// Arrange
	Customer existingCustomer = new Customer("test@example.com",
	"password", "Test User", "1234567890", "Test Address");
	/*when(customerRepository.findByEmail("test@example.com")).thenReturn(
	existingCustomer);
	// Act
	/*boolean result = customerController.verifyLogin(
	Map.of("email", "test@example.com", "password", "password"),
	"test@example.com", null);
	// Assert
	assertThat(result).isTrue();*/
	}
	@Test
	public void testVerifyLogin_Failure() {
	// Arrange
	when(customerRepository.findByEmail("test@example.com")).thenReturn(
	null);
	// Act
	boolean result = customerController.verifyLogin(
	Map.of("email", "test@example.com", "password", "password"),
	"test@example.com", null);
	// Assert
	assertThat(result).isFalse();
	}
	@Test
	public void testGetAllCustomers() {
	// Arrange
	List<Customer> customerList = List.of(
	new Customer("test1@example.com", "password", "Test User 1",
	"1234567890", "Test Address 1"),
	new Customer("test2@example.com", "password", "Test User 2",
	"1234567890", "Test Address 2")
	);
	when(customerRepository.findAll()).thenReturn(customerList);
	// Act
	List<Customer> result = customerController.getAllCustomers();
	// Assert
	assertThat(result).isNotNull();
	assertThat(result).hasSize(2);
	}
	// Add more test cases for CustomerController as needed
	}
