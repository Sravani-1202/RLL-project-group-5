package com.foodbox.controllerTest;

import com.foodbox.controller.CartController;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.foodbox.controller.CartController;
import com.foodbox.model.Cart;
import com.foodbox.model.Product;
import com.foodbox.repository.CartRepository;
@ExtendWith(MockitoExtension.class)
public class CartControllerTests {
@Mock
private CartRepository cartRepository;
@InjectMocks
private CartController cartController;
@Test
public void testAddToCart_NewItem() {
// Arrange
Cart cart = new Cart(1, 1, 100.0f, new Product(1, "Test Product",
"Description", "Category", 200.0f, 0.0f, 200.0f, "yes", "image.jpg"));
HttpSession session = mock(HttpSession.class);
when(session.getAttribute("grandTotal")).thenReturn(null);
when(cartRepository.findAll()).thenReturn(new ArrayList<>());
//Act
Cart result = cartController.addToCart(cart, session);
//Assert
/*assertThat(result).isNotNull();
assertThat(result.getId()).isGreaterThan(0);
assertThat(result.getQuantity()).isEqualTo(1);
assertThat(result.getPrice()).isEqualTo(200.0f);*/
}
@Test
public void testAddToCart_ExistingItem() {
//Arrange
Cart existingCart = new Cart(1, 1, 100.0f, new Product(1, "TestProduct", "Description", "Category", 200.0f, 0.0f, 200.0f, "yes",
"image.jpg"));
HttpSession session = mock(HttpSession.class);
when(session.getAttribute("grandTotal")).thenReturn(null);
when(cartRepository.findAll()).thenReturn(List.of(existingCart));
//Act
Cart cart = new Cart(1, 1, 100.0f, new Product(1, "Test Product",
"Description", "Category", 200.0f, 0.0f, 200.0f, "yes", "image.jpg"));
Cart result = cartController.addToCart(cart, session);
//Assert
/*assertThat(result).isNotNull();
assertThat(result.getId()).isEqualTo(existingCart.getId());
assertThat(result.getQuantity()).isEqualTo(2);
assertThat(result.getPrice()).isEqualTo(400.0f);*/
}
@Test
public void testGetCartItems() {
//Arrange
List<Cart> cartList = List.of(
new Cart(1, 2, 200.0f, new Product(1, "Product 1", "Description",
"Category", 100.0f, 0.0f, 100.0f, "yes", "image1.jpg")),
new Cart(2, 1, 150.0f, new Product(2, "Product 2", "Description",
"Category", 150.0f, 0.0f, 150.0f, "yes", "image2.jpg"))
);
when(cartRepository.findAll()).thenReturn(cartList);
//Act
List<Cart> result = cartController.getCartItems();
//Assert
assertThat(result).isNotNull();
assertThat(result).hasSize(2);
}
//Add more test cases for CartController as needed
}