package com.foodbox.controllerTest;
import com.foodbox.controller.AdminController;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;
import java.util.Map;

import javax.servlet.http.HttpSession;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.foodbox.controller.AdminController;
import com.foodbox.model.Admin;
import com.foodbox.repository.AdminRepository;
@ExtendWith(MockitoExtension.class)
public class AdminControllerTests {
@Mock
private AdminRepository adminRepository;
@InjectMocks
private AdminController adminController;
@Test
public void testVerifyAdminLogin_Success() {
// Arrange
Admin admin = new Admin("admin", "password");
when(adminRepository.findByusername("admin")).thenReturn(admin);
// Act
Map<String,String> adminMap=new HashMap<>();
adminMap.put("username","admin");
adminMap.put("password", "password");
HttpSession session = mock(HttpSession.class);
boolean result = adminController.verifyAdminLogin(adminMap, "admin",session);
System.out.println(result);
// Assert
assertThat(result).isTrue();
}
@Test
public void testVerifyAdminLogin_Failure() {
// Arrange
when(adminRepository.findByusername("admin")).thenReturn(null);
// Act
boolean result = adminController.verifyAdminLogin(
Map.of("username", "admin", "password", "password"), "admin",null);
// Assert
assertThat(result).isFalse();
}
@Test
public void testVerifyAdminLogin_NullInput() {
// Act
	Map<String,String> adminMap=new HashMap<>();
	adminMap.put("username",null);
	adminMap.put("password", null);
boolean result = adminController.verifyAdminLogin(adminMap, "admin", null);
// Assert
assertThat(result).isFalse();
}
@Test
public void testVerifyAdminLogin_EmptyUsername() {
// Act
boolean result = adminController.verifyAdminLogin(
Map.of("username", "", "password", "password"), "admin", null);
// Assert
assertThat(result).isFalse();
}
// Add more test cases for AdminController as needed
}