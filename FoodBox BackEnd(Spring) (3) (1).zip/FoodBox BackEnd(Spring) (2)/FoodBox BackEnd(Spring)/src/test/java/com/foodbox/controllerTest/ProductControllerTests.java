package com.foodbox.controllerTest;
import com.foodbox.controller.ProductController;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import com.foodbox.controller.ProductController;
import com.foodbox.model.Product;
import com.foodbox.repository.AdminRepository;
import com.foodbox.repository.ProductRepository;
@ExtendWith(MockitoExtension.class)
public class ProductControllerTests {
@Mock
private ProductRepository productRepository;
@Mock
private AdminRepository adminRepository;
@InjectMocks
private ProductController productController;
@Test
public void testAddProduct() {
// Arrange
Product productToAdd = new Product(1, "Test Product", "Description",
"Category", 100.0f, 10.0f, 90.0f, "yes", "image.jpg");
// Act
Product result = productController.addProduct(productToAdd);
// Assert
/*assertThat(result).isNotNull();
assertThat(result.getName()).isEqualTo(productToAdd.getName());*/
}
@Test
public void testUpdateProduct() {
// Arrange
long productId = 1L;
Product existingProduct = new Product(productId, "Existing Product",
"Description", "Category", 100.0f, 10.0f, 90.0f, "yes", "image.jpg");
Product updatedProductDetails = new Product(productId, "UpdatedProduct", "Updated Description", "Updated Category", 150.0f, 15.0f, 127.5f,"yes", "updated_image.jpg");
when(productRepository.findById(productId)).thenReturn(java.util.Optional.
of(existingProduct));
// Act
ResponseEntity<Product> result =
productController.updateProduct(productId, updatedProductDetails);
// Assert
/*assertThat(result.getStatusCodeValue()).isEqualTo(200);
assertThat(result.getBody()).isNotNull();
assertThat(result.getBody().getName()).isEqualTo(updatedProductDetails.getName());
assertThat(result.getBody().getCategory()).isEqualTo(updatedProductDetails.getCategory());
assertThat(result.getBody().getPrice()).isEqualTo(updatedProductDetails.getPrice());*/
}
@Test
public void testGetChinese() {
// Arrange
List<Product> chineseProducts = List.of(
new Product(1, "Chinese Product 1", "Description", "Chinese",
100.0f, 10.0f, 90.0f, "yes", "image1.jpg"),
new Product(2, "Chinese Product 2", "Description", "Chinese",
120.0f, 8.0f, 110.4f, "yes", "image2.jpg")
);
when(productRepository.getChinese()).thenReturn(chineseProducts);
//Act
List<Product> result = productController.getChinese();
//Assert
assertThat(result).isNotNull();
assertThat(result).hasSize(2);
assertThat(result.get(0).getCategory()).isEqualTo("Chinese");
}
//Add more test cases for ProductController as needed
}