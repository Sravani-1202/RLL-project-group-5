package com.foodbox.controllerTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.foodbox.controller.PurchaseController;
import com.foodbox.model.Cart;
import com.foodbox.model.Customer;
import com.foodbox.model.Product;
import com.foodbox.model.Purchase;
import com.foodbox.repository.CartRepository;
import com.foodbox.repository.CustomerRepository;
import com.foodbox.repository.PurchaseRepository;
@ExtendWith(MockitoExtension.class)public class PurchaseControllerTests {
	@Mock
	private PurchaseRepository purchaseRepository;
	@Mock
	private CartRepository cartRepository;
	@Mock
	private CustomerRepository customerRepository;
	@InjectMocks
	private PurchaseController purchaseController;
	@Test
	public void testCustomerOrders() {
	// Arrange
	String customerEmail = "test@example.com";
	List<Purchase> purchases = List.of(
	new Purchase(1, 50.0f, 2, "Product A", "ABC123", new
	Customer()),
	new Purchase(2, 30.0f, 1, "Product B", "XYZ456", new
	Customer())
	);
	when(purchaseRepository.getByEmail(customerEmail)).thenReturn(purchases);
	// Act
	List<Purchase> result =
	purchaseController.customerOrders(customerEmail);
	// Assert
	assertThat(result).isNotNull();
	assertThat(result).hasSize(2);
	assertThat(result.get(0).getProductname()).isEqualTo("Product A");
	}
	@Test
	public void testDeletePurchase() {
	// Arrange
	long purchaseId = 1L;
	Purchase purchaseToDelete = new Purchase(purchaseId, 50.0f, 2,"Product A", "ABC123", new Customer());
	when(purchaseRepository.findById(purchaseId)).thenReturn(java.util.Optional.of(purchaseToDelete));
			// Act
			ResponseEntity<Map<String, Boolean>> result =
			purchaseController.deletePurchase(purchaseId);
			// Assert
			assertThat(result.getStatusCodeValue()).isEqualTo(HttpStatus.OK.value());
			assertThat(result.getBody()).isNotNull();
			assertThat(result.getBody().get("deleted")).isEqualTo(true);
			}
			@Test
			public void testBuyProducts() {
			// Arrange
			String customerEmail = "test@example.com";
			Map<String, Object> buyProdMap = Map.of("email", customerEmail,
			"transactionId", "ABC123");
			Customer customer = new Customer(customerEmail, "password",
			"John Doe", "1234567890", "123 Main St");
			when(customerRepository.findByEmail(customerEmail)).thenReturn(customer);
			List<Cart> cartList = List.of(
			new Cart(1, 2, 30.0f, new Product()),
			new Cart(2, 1, 20.0f, new Product())
			);
			when(cartRepository.findAll()).thenReturn(cartList);
			// Act
			ResponseEntity<Map<String, Boolean>> result =
			purchaseController.buyProducts(buyProdMap);
			// Assert
			assertThat(result.getStatusCodeValue()).isEqualTo(HttpStatus.OK.value());
			assertThat(result.getBody()).isNotNull();
			assertThat(result.getBody().get("created")).isEqualTo(true);
			}
			// Add more test cases for PurchaseController as needed
			}